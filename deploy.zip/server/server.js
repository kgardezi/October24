'use strict';
/* =====================================================================
   Idea Board team server
   - Serves the app (public/index.html)
   - Stores boards as JSON files in DATA_DIR (default ./data)
   - REST API for listing / creating / renaming / sharing / deleting boards
   - WebSocket (/ws) for live collaboration: shape changes, pages, names,
     pictures, cursors, laser pointers, presence
   Zero dependencies: only Node.js built-ins (Node 18+).
   ===================================================================== */
const http = require('http');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');

const PORT = +process.env.PORT || 8080;
const HOST = process.env.HOST || '0.0.0.0';
const DATA = path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data'));
const PUBLIC = path.resolve(process.env.PUBLIC_DIR || path.join(__dirname, 'public'));
const MAX_BODY = 40 * 1024 * 1024;           // 40 MB (boards with pictures)
const MAX_WS_MSG = 40 * 1024 * 1024;
const SAVE_DELAY = 800;                        // ms after the last change
const UNLOAD_AFTER = 5 * 60 * 1000;            // drop idle boards from memory
const VERSION = '2.0.0';

fs.mkdirSync(path.join(DATA, 'boards'), {recursive: true});
const log = (...a) => console.log(new Date().toISOString(), ...a);
const newId = () => crypto.randomBytes(8).toString('hex');
const validId = id => typeof id === 'string' && /^[a-z0-9]{6,32}$/i.test(id);
const clean = (v, n = 80) => String(v == null ? '' : v).replace(/[\u0000-\u001f]/g, '').trim().slice(0, n);
const same = (a, b) => clean(a).toLowerCase() === clean(b).toLowerCase();

/* ---------- storage ---------- */
const INDEX_FILE = path.join(DATA, 'index.json');
let index = [];                                   // [{id,name,owner,shared,created,updated,updatedBy,pages}]
try { index = JSON.parse(fs.readFileSync(INDEX_FILE, 'utf8')); if (!Array.isArray(index)) index = []; } catch (e) { index = []; }
function writeAtomic(file, text){
  const tmp = file + '.' + process.pid + '.tmp';
  fs.writeFileSync(tmp, text);
  fs.renameSync(tmp, file);
}
let indexTimer = null;
function saveIndex(now = false){
  clearTimeout(indexTimer);
  const go = () => { try { writeAtomic(INDEX_FILE, JSON.stringify(index, null, 1)); } catch (e) { log('index write failed', e.message); } };
  if (now) go(); else indexTimer = setTimeout(go, 300);
}
const meta = id => index.find(b => b.id === id);
const boardFile = id => path.join(DATA, 'boards', id + '.json');
function emptyDoc(name){ return {name, pages: [{id: newId(), name: '', shapes: []}], assets: {}}; }
function normDoc(d, name){
  d = d && typeof d === 'object' ? d : {};
  let pages = Array.isArray(d.pages) && d.pages.length ? d.pages : Array.isArray(d.shapes) ? [{id: newId(), name: '', shapes: d.shapes}] : null;
  if (!pages) pages = emptyDoc().pages;
  pages = pages.map(p => ({id: validId(p.id) ? p.id : newId(), name: clean(p.name, 60), shapes: Array.isArray(p.shapes) ? p.shapes.filter(s => s && typeof s.id === 'string') : []}));
  return {name: clean(d.name || name || 'Untitled board') || 'Untitled board', pages, assets: d.assets && typeof d.assets === 'object' ? d.assets : {}};
}

/* open boards held in memory */
const live = new Map();   // id -> {doc, clients:Set, timer, dirty, unloadTimer}
function getLive(id){
  let b = live.get(id);
  if (b) return b;
  const m = meta(id); if (!m) return null;
  let doc;
  try { doc = normDoc(JSON.parse(fs.readFileSync(boardFile(id), 'utf8')), m.name); }
  catch (e) { doc = emptyDoc(m.name); }
  b = {doc, clients: new Set(), timer: null, dirty: false, unloadTimer: null};
  live.set(id, b);
  scheduleUnload(id);
  return b;
}
function scheduleUnload(id){
  const b = live.get(id); if (!b) return;
  clearTimeout(b.unloadTimer);
  b.unloadTimer = setTimeout(() => { if (b.clients.size === 0){ flush(id); live.delete(id); } else scheduleUnload(id); }, UNLOAD_AFTER);
}
function markDirty(id, user){
  const b = live.get(id); if (!b) return;
  b.dirty = true;
  const m = meta(id); if (m){ m.updated = Date.now(); if (user) m.updatedBy = clean(user, 60); m.pages = b.doc.pages.length; m.name = b.doc.name; saveIndex(); }
  clearTimeout(b.timer); b.timer = setTimeout(() => flush(id), SAVE_DELAY);
}
function flush(id){
  const b = live.get(id); if (!b || !b.dirty) return;
  clearTimeout(b.timer); b.dirty = false;
  // drop pictures nothing uses any more
  const used = new Set(); for (const p of b.doc.pages) for (const s of p.shapes) if (s.type === 'image') used.add(s.asset);
  for (const k of Object.keys(b.doc.assets)) if (!used.has(k)) delete b.doc.assets[k];
  try { writeAtomic(boardFile(id), JSON.stringify(b.doc)); } catch (e) { log('board write failed', id, e.message); }
}
function flushAll(){ for (const id of live.keys()) flush(id); saveIndex(true); }
process.on('SIGTERM', () => { flushAll(); process.exit(0); });
process.on('SIGINT', () => { flushAll(); process.exit(0); });
setInterval(() => { for (const id of live.keys()) flush(id); }, 30000).unref();

function createBoard({name, owner, shared, doc}){
  const id = newId(), now = Date.now();
  const d = normDoc(doc, name); d.name = clean(name || d.name) || 'Untitled board';
  writeAtomic(boardFile(id), JSON.stringify(d));
  const m = {id, name: d.name, owner: clean(owner, 60) || 'unknown', shared: !!shared, created: now, updated: now, updatedBy: clean(owner, 60), pages: d.pages.length};
  index.push(m); saveIndex(true);
  return m;
}
const canSee = (m, user) => m && (m.shared || same(m.owner, user));

/* ---------- live document operations ---------- */
function pageOf(doc, pid, create){
  let p = doc.pages.find(x => x.id === pid);
  if (!p && create && validId(pid)){ p = {id: pid, name: '', shapes: []}; doc.pages.push(p); }
  return p;
}
function applyOp(doc, op){
  switch (op.t){
    case 'batch': {
      const p = pageOf(doc, op.page, true); if (!p) return false;
      if (Array.isArray(op.put)) for (const s of op.put){
        if (!s || typeof s.id !== 'string') continue;
        const i = p.shapes.findIndex(x => x.id === s.id);
        if (i >= 0) p.shapes[i] = s; else p.shapes.push(s);
      }
      if (Array.isArray(op.del)){ const d = new Set(op.del); p.shapes = p.shapes.filter(x => !d.has(x.id)); }
      if (Array.isArray(op.order)){ const pos = new Map(op.order.map((id, i) => [id, i])); p.shapes.sort((a, b) => (pos.has(a.id) ? pos.get(a.id) : 1e9) - (pos.has(b.id) ? pos.get(b.id) : 1e9)); }
      return true;
    }
    case 'pages': {
      if (!Array.isArray(op.pages) || !op.pages.length) return false;
      const old = new Map(doc.pages.map(p => [p.id, p]));
      doc.pages = op.pages.filter(p => p && validId(p.id)).map(p => { const o = old.get(p.id); return {id: p.id, name: clean(p.name, 60), shapes: o ? o.shapes : []}; });
      if (!doc.pages.length) doc.pages = emptyDoc().pages;
      return true;
    }
    case 'meta': { if (typeof op.name !== 'string') return false; doc.name = clean(op.name) || 'Untitled board'; return true; }
    case 'asset': { if (!validId(op.id) || typeof op.data !== 'string' || !op.data.startsWith('data:image/')) return false; doc.assets[op.id] = op.data; return true; }
  }
  return false;
}

/* ---------- HTTP ---------- */
const MIME = {'.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8', '.woff2': 'font/woff2'};
const SEC = {
  'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'SAMEORIGIN', 'Referrer-Policy': 'no-referrer',
  'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self' ws: wss:",
};
function send(res, code, body, type = 'application/json'){
  const data = type === 'application/json' ? JSON.stringify(body) : body;
  res.writeHead(code, {'Content-Type': type, 'Cache-Control': 'no-store', ...SEC});
  res.end(data);
}
function readBody(req){
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > MAX_BODY){ reject(Object.assign(new Error('too large'), {code: 413})); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch (e) { reject(Object.assign(new Error('bad json'), {code: 400})); } });
    req.on('error', reject);
  });
}
async function api(req, res, url){
  const parts = url.pathname.replace(/^\/api\/?/, '').split('/').filter(Boolean);
  const user = clean(url.searchParams.get('user'), 60);
  if (parts[0] === 'health') return send(res, 200, {ok: true, app: 'idea-board', version: VERSION});
  if (parts[0] !== 'boards') return send(res, 404, {error: 'not found'});

  if (parts.length === 1){
    if (req.method === 'GET'){
      const list = index.filter(m => canSee(m, user)).map(m => ({...m, online: live.get(m.id) ? live.get(m.id).clients.size : 0}));
      return send(res, 200, list.sort((a, b) => b.updated - a.updated));
    }
    if (req.method === 'POST'){
      const b = await readBody(req);
      const owner = clean(b.owner || user, 60); if (!owner) return send(res, 400, {error: 'name required'});
      const m = createBoard({name: b.name, owner, shared: !!b.shared, doc: b.doc});
      log('board created', m.id, JSON.stringify(m.name), 'by', owner, m.shared ? '(team)' : '(private)');
      return send(res, 201, m);
    }
    return send(res, 405, {error: 'method'});
  }
  const id = parts[1]; if (!validId(id)) return send(res, 400, {error: 'bad id'});
  const m = meta(id); if (!m || !canSee(m, user)) return send(res, 404, {error: 'board not found'});

  if (parts[2] === 'duplicate' && req.method === 'POST'){
    const b = await readBody(req);
    const src = getLive(id); flush(id);
    const copy = JSON.parse(JSON.stringify(src.doc));
    const nm = createBoard({name: clean(b.name) || m.name + ' copy', owner: user || b.owner, shared: false, doc: copy});
    return send(res, 201, nm);
  }
  if (parts.length > 2) return send(res, 404, {error: 'not found'});
  if (req.method === 'GET'){ const b = getLive(id); return send(res, 200, {...m, doc: b.doc}); }
  if (req.method === 'PATCH'){
    const b = await readBody(req);
    if (typeof b.shared === 'boolean' && b.shared !== m.shared){
      if (!same(m.owner, user)) return send(res, 403, {error: 'only the owner can change sharing'});
      m.shared = b.shared;
      if (!m.shared) for (const c of (live.get(id) || {clients: []}).clients) if (!same(c.user.name, m.owner)) wsSend(c, {t: 'deleted', reason: 'The owner made this board private'});
    }
    if (typeof b.name === 'string'){ const lb = getLive(id); lb.doc.name = clean(b.name) || 'Untitled board'; m.name = lb.doc.name; markDirty(id, user); broadcast(id, {t: 'meta', name: m.name}); }
    m.updated = Date.now(); saveIndex();
    return send(res, 200, m);
  }
  if (req.method === 'DELETE'){
    if (!same(m.owner, user)) return send(res, 403, {error: 'only the owner can delete this board'});
    const lb = live.get(id);
    if (lb){ for (const c of lb.clients) wsSend(c, {t: 'deleted', reason: 'This board was deleted by its owner'}); clearTimeout(lb.timer); live.delete(id); }
    index = index.filter(x => x.id !== id); saveIndex(true);
    try { fs.renameSync(boardFile(id), path.join(DATA, 'boards', id + '.deleted-' + Date.now() + '.json')); } catch (e) {}
    log('board deleted', id, 'by', user);
    return send(res, 200, {ok: true});
  }
  return send(res, 405, {error: 'method'});
}
/* Only the app itself is ever served — never board data or server files. */
const STATIC = {'/': 'index.html', '/index.html': 'index.html', '/FONT-LICENSE.txt': 'FONT-LICENSE.txt'};
async function serveStatic(req, res, url){
  const name = STATIC[url.pathname];
  if (!name) return send(res, 404, 'not found', 'text/plain');
  for (const dir of [PUBLIC, path.join(__dirname, '..')]){          // Docker: /app/public · from a checkout: the project folder
    try {
      const data = await fsp.readFile(path.join(dir, name));
      res.writeHead(200, {'Content-Type': MIME[path.extname(name)] || 'application/octet-stream', 'Cache-Control': 'no-cache', ...SEC});
      return res.end(req.method === 'HEAD' ? undefined : data);
    } catch (e) {}
  }
  send(res, 404, 'not found', 'text/plain');
}
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  try {
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, {error: 'method'});
    return await serveStatic(req, res, url);
  } catch (e) {
    send(res, e.code === 413 ? 413 : e.code === 400 ? 400 : 500, {error: e.message});
    if (!e.code) log('error', e.stack);
  }
});

/* ---------- WebSocket (RFC 6455, no dependencies) ---------- */
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
function wsFrame(data, opcode = 1){
  const payload = Buffer.isBuffer(data) ? data : Buffer.from(data);
  const len = payload.length; let head;
  if (len < 126){ head = Buffer.alloc(2); head[1] = len; }
  else if (len < 65536){ head = Buffer.alloc(4); head[1] = 126; head.writeUInt16BE(len, 2); }
  else { head = Buffer.alloc(10); head[1] = 127; head.writeBigUInt64BE(BigInt(len), 2); }
  head[0] = 0x80 | opcode;
  return Buffer.concat([head, payload]);
}
function wsSend(c, obj){ if (!c.closed) try { c.sock.write(wsFrame(JSON.stringify(obj))); } catch (e) {} }
function broadcast(boardId, obj, except){
  const b = live.get(boardId); if (!b) return;
  const frame = wsFrame(JSON.stringify(obj));
  for (const c of b.clients) if (c !== except && !c.closed) try { c.sock.write(frame); } catch (e) {}
}
function presence(boardId){
  const b = live.get(boardId); if (!b) return;
  broadcast(boardId, {t: 'presence', users: [...b.clients].filter(c => c.user).map(c => ({id: c.user.id, name: c.user.name, color: c.user.color, page: c.page}))});
}
server.on('upgrade', (req, sock) => {
  const url = new URL(req.url, 'http://x');
  const key = req.headers['sec-websocket-key'];
  if (!url.pathname.endsWith('/ws') || !key){ sock.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  sock.setNoDelay(true);
  const c = {sock, board: null, user: null, page: null, closed: false, alive: true};
  let buf = Buffer.alloc(0), frags = [], fragOp = 0;
  const close = () => {
    if (c.closed) return; c.closed = true;
    try { sock.end(wsFrame(Buffer.alloc(0), 8)); } catch (e) {}
    const b = c.board && live.get(c.board);
    if (b){ b.clients.delete(c); presence(c.board); scheduleUnload(c.board); if (!b.clients.size) flush(c.board); }
  };
  sock.on('data', chunk => {
    buf = buf.length ? Buffer.concat([buf, chunk]) : chunk;
    while (buf.length >= 2){
      const fin = (buf[0] & 0x80) !== 0, op = buf[0] & 0x0f, masked = (buf[1] & 0x80) !== 0;
      let len = buf[1] & 0x7f, off = 2;
      if (len === 126){ if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; }
      else if (len === 127){ if (buf.length < 10) return; len = Number(buf.readBigUInt64BE(2)); off = 10; }
      if (len > MAX_WS_MSG){ close(); return; }
      const maskOff = off; if (masked) off += 4;
      if (buf.length < off + len) return;
      let payload = buf.subarray(off, off + len);
      if (masked){ const mask = buf.subarray(maskOff, maskOff + 4); payload = Buffer.from(payload); for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3]; }
      buf = buf.subarray(off + len);
      if (op === 8){ close(); return; }
      if (op === 9){ try { sock.write(wsFrame(payload, 10)); } catch (e) {} continue; }
      if (op === 10){ c.alive = true; continue; }
      if (op === 1 || op === 2){ frags = [payload]; fragOp = op; }
      else if (op === 0){ frags.push(payload); }
      else continue;
      if (!fin) continue;
      const msg = Buffer.concat(frags).toString('utf8'); frags = [];
      if (fragOp !== 1) continue;
      let m; try { m = JSON.parse(msg); } catch (e) { continue; }
      onMessage(c, m);
    }
  });
  sock.on('close', close); sock.on('error', close); sock.on('end', close);
  c.ping = setInterval(() => {
    if (c.closed){ clearInterval(c.ping); return; }
    if (!c.alive){ close(); clearInterval(c.ping); return; }
    c.alive = false; try { sock.write(wsFrame(Buffer.alloc(0), 9)); } catch (e) {}
  }, 30000);
});
function onMessage(c, m){
  if (m.t === 'hello'){
    const mt = meta(m.board);
    c.user = {id: clean(m.user && m.user.id, 40) || newId(), name: clean(m.user && m.user.name, 60) || 'Guest', color: clean(m.user && m.user.color, 20) || '#1f6feb'};
    if (!mt || !canSee(mt, c.user.name)){ wsSend(c, {t: 'deleted', reason: 'Board not found'}); return; }
    const b = getLive(m.board);
    c.board = m.board; c.page = m.page || null; b.clients.add(c);
    wsSend(c, {t: 'init', board: {...mt, doc: b.doc}});
    presence(c.board);
    return;
  }
  if (!c.board) return;
  const b = live.get(c.board); if (!b) return;
  switch (m.t){
    case 'batch': case 'pages': case 'meta': case 'asset':
      if (applyOp(b.doc, m)){
        markDirty(c.board, c.user.name);
        broadcast(c.board, {...m, from: c.user.id}, c);
        if (m.t === 'meta'){ const mt = meta(c.board); if (mt) mt.name = b.doc.name; }
      }
      break;
    case 'page': c.page = m.page; presence(c.board); break;
    case 'cursor': case 'laser': broadcast(c.board, {...m, from: c.user.id, name: c.user.name, color: c.user.color}, c); break;
  }
}

server.listen(PORT, HOST, () => log(`Idea Board server ${VERSION} on http://${HOST}:${PORT}  data=${DATA}`));
